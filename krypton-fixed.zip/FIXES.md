# Krypton 1.21.11 – danh sách đã sửa

## Đã sửa (tĩnh, chưa biên dịch được vì không có mạng/Gradle)
- 165 import `net.minecraft.X` bị làm phẳng → đã trả về đúng package Yarn (107 file).
- Class lồng sai cú pháp `Outer.Outer$Inner` → `Outer.Inner` (InputUtil.Key, Direction.Axis, HitResult.Type...).
- Class bị gỡ: SwordItem/ArmorItem/ToolItem/ShieldItem/ShearsItem → ItemTags.SWORDS, component EQUIPPABLE/TOOL, Items.SHIELD/SHEARS.
- `PlayerInventory.selectedSlot` (private từ 1.21.5) → getSelectedSlot()/setSelectedSlot().
- Token intermediary/placeholder: method_7848, method_23666, method_19538, method_19326, method_3054, method_10163,
  method_57824/57829, method_45731, method_11734/5/8, field_1703, field_7544, method_7372, method_4624, comp_*.
- Lỗi logic: AutoEat điều kiện `!= null` bị ngược + có thể gọi getStack(-1); PositionPacketFilter in sai biến (y/z).
- AutoTool: BambooShootBlock → BambooSaplingBlock; kiểm tra kéo (shears) viết lại đúng.

## Còn chặn build (cần port sang render pipeline 1.21.11, không làm mù được)
RenderUtils, GlyphPage, GlyphPageFontRenderer, PlayerESP: BufferRenderer/class_286, GameRenderer::getPosition*Program,
ShaderProgram, VertexSorter, RenderSystem.setShader đã bị loại bỏ.

## Cần kiểm tra khi có compiler
- Mixin target/descriptor (CameraMixin, GameRendererMixin, EntityRenderDispatcherMixin...) so với 1.21.11.
- Tên Yarn đoán theo 1.21.9+: Entity.getEntityPos, Camera.getCameraPos, PlayerPositionLookS2CPacket.change().
