# Krypton source port audit

- Input binary manifest reports Minecraft **1.21.1**, intermediary namespace.
- Input decompiler archive: 144 Java files.
- Target mapping supplied by user: Yarn 1.21.11+build.4.
- `protect.zip` is a separate `coindebug` project with a Meteor Client dependency; it is not a Gradle project for Krypton. I created a Krypton-specific Loom scaffold instead.

## Automated changes applied
- Remapped classes, method IDs and field IDs when target Yarn mappings contain a unique matching entry.
- Updated Fabric metadata to Krypton / Minecraft 1.21.11 / Java 21.
- Added Loom build files targeting Yarn build.4 and Fabric Loader 0.18.1.
- Moved Java and resource files to Gradle's standard source layout.
- Reset the old 1.21.1 refmap so Loom can generate the target refmap on a build.

## Static scan
- Remaining intermediary tokens: 108 occurrences (28 distinct tokens).
- Source files still importing `net.minecraft.class_...`: 8.
- Mixin class names missing from source: none.
- Unmapped class IDs: 36 occurrences (5 tokens).
- Method IDs not uniquely mapped: 69 occurrences (20 tokens).
- Field IDs not uniquely mapped: 3 occurrences (3 tokens).

## Build verification limitation
This package is **not yet verified to compile**. The runtime has Java 21 but no Gradle installation/cached Fabric and Minecraft dependencies, and network access is unavailable. The original client targets 1.21.1; 1.21.11 contains API changes (notably rendering), and removed classes/method IDs cannot safely be repaired by global mapping alone. Run `gradle build --no-daemon` in an environment with internet/Gradle and iterate on actual compiler diagnostics.

## Remaining intermediary tokens
method_19538 (15), class_286 (15), method_43433 (11), class_293 (9), method_19326 (8), method_34540 (5), class_1829 (5), class_1738 (5), method_23666 (4), method_7848 (3), method_3054 (3), method_7372 (3), method_57829 (3), method_8322 (3), method_57824 (2), class_1831 (2), method_10163 (1), field_7544 (1), method_7685 (1), method_11734 (1), method_11735 (1), method_11738 (1), method_45731 (1), field_4344 (1), method_34539 (1), field_1703 (1), method_4624 (1), method_34543 (1)


## Known unresolved blockers identified during manual review
- `class_286` / `method_43433` in the old renderer code refer to the legacy BufferRenderer path, which is absent from the supplied 1.21.11 Yarn mappings; rendering code in `RenderUtils`, `PlayerESP`, and custom font renderers must be ported to the newer render pipeline.
- `class_293` was the old Minecraft-package VertexFormat reference; its replacement is now the Mojang package `com.mojang.blaze3d.vertex.VertexFormat`. The nested `DrawMode` import has been corrected, but rendering method calls still need a proper 1.21.11 implementation.
- Old intermediary IDs for `SwordItem`, `ElytraItem`, and another tool item class are absent from the supplied target mappings. Their replacements must be verified against the actual 1.21.11 Minecraft jar rather than guessed.
