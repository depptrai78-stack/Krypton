package skid.krypton.module.modules.misc;

import java.util.concurrent.CompletableFuture;
import skid.krypton.event.EventListener;
import skid.krypton.event.events.TickEvent;
import skid.krypton.module.Category;
import skid.krypton.module.Module;
import skid.krypton.module.setting.BindSetting;
import skid.krypton.module.setting.Setting;
import skid.krypton.module.setting.StringSetting;
import skid.krypton.utils.EncryptedString;
import skid.krypton.utils.KeyUtils;
import skid.krypton.utils.embed.DiscordWebhook;

public final class CordSnapper extends Module {
   private final BindSetting activateKey = new BindSetting(EncryptedString.of("Activate Key"), -1, false);
   private final StringSetting webhookUrl = new StringSetting(EncryptedString.of("Webhook"), "");
   private int cooldownCounter = 0;

   public CordSnapper() {
      super(EncryptedString.of("Cord Snapper"), EncryptedString.of("Sends base coordinates to discord webhook"), -1, Category.MISC);
      this.addSettings(new Setting[]{this.activateKey, this.webhookUrl});
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.player != null) {
         if (this.cooldownCounter > 0) {
            --this.cooldownCounter;
         } else {
            if (KeyUtils.isKeyPressed(this.activateKey.getValue())) {
               DiscordWebhook embedSender = new DiscordWebhook(this.webhookUrl.value);
               double var10001 = this.mc.player.getX();
               embedSender.a("Coordinates: x: " + var10001 + " y: " + this.mc.player.getY() + " z: " + this.mc.player.getZ());
               CompletableFuture.runAsync(() -> {
                  try {
                     embedSender.execute();
                  } catch (Throwable _t) {
                     _t.printStackTrace(System.err);
                  }

               });
               this.cooldownCounter = 40;
            }

         }
      }
   }
}
