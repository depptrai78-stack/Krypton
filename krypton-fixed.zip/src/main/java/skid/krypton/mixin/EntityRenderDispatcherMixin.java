package skid.krypton.mixin;

import net.minecraft.util.math.Box;
import net.minecraft.client.render.entity.EntityRenderManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import skid.krypton.Krypton;
import skid.krypton.module.Module;
import skid.krypton.module.modules.combat.Hitbox;

@Mixin({EntityRenderManager.class})
public class EntityRenderDispatcherMixin {
   @ModifyVariable(
      method = {"renderHitbox"},
      ordinal = 0,
      at = @At(
   value = "STORE",
   ordinal = 0
)
   )
   private static Box onRenderHitboxEditBox(Box box) {
      Module hitboxes = Krypton.INSTANCE.MODULE_MANAGER.getModuleByClass(Hitbox.class);
      return hitboxes.isEnabled() ? box.expand(((Hitbox)hitboxes).getHitboxExpansion()) : box;
   }
}
