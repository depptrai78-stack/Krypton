package skid.krypton.utils;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import skid.krypton.font.Fonts;
import skid.krypton.module.modules.client.Krypton;

public final class TextRenderer {
   public static void drawString(CharSequence charSequence, DrawContext drawContext, int n, int n2, int n3) {
      if (Krypton.useCustomFont.getValue()) {
         Fonts.FONT.drawString(drawContext.getMatrices(), charSequence, (float)n, (float)n2, n3);
      } else {
         drawLargeString(charSequence, drawContext, n, n2, n3);
      }

   }

   public static int getWidth(CharSequence charSequence) {
      return Krypton.useCustomFont.getValue() ? Fonts.FONT.getStringWidth(charSequence) : skid.krypton.Krypton.mc.textRenderer.getWidth(charSequence.toString()) * 2;
   }

   public static void drawCenteredString(CharSequence charSequence, DrawContext drawContext, int n, int n2, int n3) {
      if (Krypton.useCustomFont.getValue()) {
         Fonts.FONT.drawString(drawContext.getMatrices(), charSequence, (float)(n - Fonts.FONT.getStringWidth(charSequence) / 2), (float)n2, n3);
      } else {
         drawCenteredMinecraftText(charSequence, drawContext, n, n2, n3);
      }

   }

   public static void drawLargeString(CharSequence charSequence, DrawContext drawContext, int n, int n2, int n3) {
      MatrixStack matrices = drawContext.getMatrices();
      matrices.push();
      matrices.scale(2.0F, 2.0F, 2.0F);
      drawContext.drawText(skid.krypton.Krypton.mc.textRenderer, charSequence.toString(), n / 2, n2 / 2, n3, false);
      matrices.scale(1.0F, 1.0F, 1.0F);
      matrices.pop();
   }

   public static void drawCenteredMinecraftText(CharSequence charSequence, DrawContext drawContext, int n, int n2, int n3) {
      MatrixStack matrices = drawContext.getMatrices();
      matrices.push();
      matrices.scale(2.0F, 2.0F, 2.0F);
      drawContext.drawText(skid.krypton.Krypton.mc.textRenderer, (String)charSequence, n / 2 - skid.krypton.Krypton.mc.textRenderer.getWidth((String)charSequence) / 2, n2 / 2, n3, false);
      matrices.scale(1.0F, 1.0F, 1.0F);
      matrices.pop();
   }
}
