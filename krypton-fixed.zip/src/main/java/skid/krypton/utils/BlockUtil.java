package skid.krypton.utils;

import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.block.RespawnAnchorBlock;
import skid.krypton.Krypton;

public final class BlockUtil {
   public static Stream<WorldChunk> getLoadedChunks() {
      int radius = Math.max(2, Krypton.mc.options.getClampedViewDistance()) + 3;
      int diameter = radius * 2 + 1;
      ChunkPos center = Krypton.mc.player.getChunkPos();
      ChunkPos min = new ChunkPos(center.x - radius, center.z - radius);
      ChunkPos max = new ChunkPos(center.x + radius, center.z + radius);
      return Stream.iterate(min, (pos) -> {
         int x = pos.x;
         int z = pos.z;
         ++x;
         if (x > max.x) {
            x = min.x;
            ++z;
         }

         if (z > max.z) {
            throw new IllegalStateException("Stream limit didn't work.");
         } else {
            return new ChunkPos(x, z);
         }
      }).limit((long)diameter * (long)diameter).filter((c) -> Krypton.mc.world.isChunkLoaded(c.x, c.z)).map((c) -> Krypton.mc.world.getChunk(c.x, c.z)).filter(Objects::nonNull);
   }

   public static boolean isBlockAtPosition(BlockPos blockPos, Block block) {
      return Krypton.mc.world.getBlockState(blockPos).getBlock() == block;
   }

   public static boolean isRespawnAnchorCharged(BlockPos blockPos) {
      return isBlockAtPosition(blockPos, Blocks.RESPAWN_ANCHOR) && (Integer)Krypton.mc.world.getBlockState(blockPos).get(RespawnAnchorBlock.CHARGES) != 0;
   }

   public static boolean isRespawnAnchorUncharged(BlockPos blockPos) {
      return isBlockAtPosition(blockPos, Blocks.RESPAWN_ANCHOR) && (Integer)Krypton.mc.world.getBlockState(blockPos).get(RespawnAnchorBlock.CHARGES) == 0;
   }

   public static void interactWithBlock(BlockHitResult blockHitResult, boolean shouldSwingHand) {
      ActionResult result = Krypton.mc.interactionManager.interactBlock(Krypton.mc.player, Hand.MAIN_HAND, blockHitResult);
      if (result.isAccepted() && result.shouldSwingHand() && shouldSwingHand) {
         Krypton.mc.player.swingHand(Hand.MAIN_HAND);
      }

   }
}
