package skid.krypton.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import skid.krypton.Krypton;
import skid.krypton.module.Category;
import skid.krypton.utils.ColorUtil;
import skid.krypton.utils.RenderUtils;
import skid.krypton.utils.TextRenderer;

public final class ClickGUI extends Screen {
   public List<CategoryWindow> windows = new ArrayList();
   public Color currentColor;
   private CharSequence tooltipText = null;
   private int tooltipX;
   private int tooltipY;
   private final Color DESCRIPTION_BG = new Color(40, 40, 40, 200);

   public ClickGUI() {
      super(Text.empty());
      int n = 50;
      Category[] values = Category.values();

      for(Category value : values) {
         this.windows.add(new CategoryWindow(n, 50, 230, 30, value, this));
         n += 250;
      }

   }

   public boolean isDraggingAlready() {
      for(CategoryWindow window : this.windows) {
         if (window.dragging) {
            return true;
         }
      }

      return false;
   }

   public void setTooltip(CharSequence tooltipText, int tooltipX, int tooltipY) {
      this.tooltipText = tooltipText;
      this.tooltipX = tooltipX;
      this.tooltipY = tooltipY;
   }

   public void setInitialFocus() {
      if (this.client != null) {
         super.setInitialFocus();
      }
   }

   public void render(DrawContext drawContext, int n, int n2, float n3) {
      if (Krypton.mc.currentScreen == this) {
         if (Krypton.INSTANCE.screen != null) {
            Krypton.INSTANCE.screen.render(drawContext, 0, 0, n3);
         }

         if (this.currentColor == null) {
            this.currentColor = new Color(0, 0, 0, 0);
         } else {
            this.currentColor = new Color(0, 0, 0, this.currentColor.getAlpha());
         }

         int alpha = this.currentColor.getAlpha();
         int n4;
         if (skid.krypton.module.modules.client.Krypton.renderBackground.getValue()) {
            n4 = 200;
         } else {
            n4 = 0;
         }

         if (alpha != n4) {
            int n5;
            if (skid.krypton.module.modules.client.Krypton.renderBackground.getValue()) {
               n5 = 200;
            } else {
               n5 = 0;
            }

            this.currentColor = ColorUtil.a(0.05F, n5, this.currentColor);
         }

         if (Krypton.mc.currentScreen instanceof ClickGUI) {
            drawContext.fill(0, 0, Krypton.mc.getWindow().getWidth(), Krypton.mc.getWindow().getHeight(), this.currentColor.getRGB());
         }

         RenderUtils.unscaledProjection();
         int n6 = n * (int)MinecraftClient.getInstance().getWindow().getScaleFactor();
         int n7 = n2 * (int)MinecraftClient.getInstance().getWindow().getScaleFactor();
         super.render(drawContext, n6, n7, n3);

         for(CategoryWindow next : this.windows) {
            next.render(drawContext, n6, n7, n3);
            next.updatePosition((double)n6, (double)n7, n3);
         }

         if (this.tooltipText != null) {
            this.renderTooltip(drawContext, this.tooltipText, this.tooltipX, this.tooltipY);
            this.tooltipText = null;
         }

         RenderUtils.scaledProjection();
      }

   }

   public boolean keyPressed(int n, int n2, int n3) {
      Iterator<CategoryWindow> iterator = this.windows.iterator();

      while(iterator.hasNext()) {
         ((CategoryWindow)iterator.next()).keyPressed(n, n2, n3);
      }

      return super.keyPressed(n, n2, n3);
   }

   public boolean mouseClicked(double n, double n2, int n3) {
      double n4 = n * (double)((int)MinecraftClient.getInstance().getWindow().getScaleFactor());
      double n5 = n2 * (double)((int)MinecraftClient.getInstance().getWindow().getScaleFactor());
      Iterator<CategoryWindow> iterator = this.windows.iterator();

      while(iterator.hasNext()) {
         ((CategoryWindow)iterator.next()).mouseClicked(n4, n5, n3);
      }

      return super.mouseClicked(n4, n5, n3);
   }

   public boolean mouseDragged(double n, double n2, int n3, double n4, double n5) {
      double n6 = n * (double)((int)MinecraftClient.getInstance().getWindow().getScaleFactor());
      double n7 = n2 * (double)((int)MinecraftClient.getInstance().getWindow().getScaleFactor());
      Iterator<CategoryWindow> iterator = this.windows.iterator();

      while(iterator.hasNext()) {
         ((CategoryWindow)iterator.next()).mouseDragged(n6, n7, n3, n4, n5);
      }

      return super.mouseDragged(n6, n7, n3, n4, n5);
   }

   public boolean mouseScrolled(double n, double n2, double n3, double n4) {
      double n5 = n2 * MinecraftClient.getInstance().getWindow().getScaleFactor();
      Iterator<CategoryWindow> iterator = this.windows.iterator();

      while(iterator.hasNext()) {
         ((CategoryWindow)iterator.next()).mouseScrolled(n, n5, n3, n4);
      }

      return super.mouseScrolled(n, n5, n3, n4);
   }

   public boolean shouldPause() {
      return false;
   }

   public void close() {
      Krypton.INSTANCE.getModuleManager().getModuleByClass(skid.krypton.module.modules.client.Krypton.class).setEnabled(false);
      this.onGuiClose();
   }

   public void onGuiClose() {
      Krypton.mc.setScreenAndRender(Krypton.INSTANCE.screen);
      this.currentColor = null;
      Iterator<CategoryWindow> iterator = this.windows.iterator();

      while(iterator.hasNext()) {
         ((CategoryWindow)iterator.next()).onGuiClose();
      }

   }

   public boolean mouseReleased(double n, double n2, int n3) {
      double n4 = n * (double)((int)MinecraftClient.getInstance().getWindow().getScaleFactor());
      double n5 = n2 * (double)((int)MinecraftClient.getInstance().getWindow().getScaleFactor());
      Iterator<CategoryWindow> iterator = this.windows.iterator();

      while(iterator.hasNext()) {
         ((CategoryWindow)iterator.next()).mouseReleased(n4, n5, n3);
      }

      return super.mouseReleased(n4, n5, n3);
   }

   private void renderTooltip(DrawContext drawContext, CharSequence charSequence, int n, int n2) {
      if (charSequence != null && charSequence.length() != 0) {
         int a = TextRenderer.getWidth(charSequence);
         int framebufferWidth = Krypton.mc.getWindow().getFramebufferWidth();
         if (n + a + 10 > framebufferWidth) {
            n = framebufferWidth - a - 10;
         }

         RenderUtils.renderRoundedQuad(drawContext.getMatrices(), this.DESCRIPTION_BG, (double)(n - 5), (double)(n2 - 5), (double)(n + a + 5), (double)(n2 + 15), (double)6.0F, (double)6.0F, (double)6.0F, (double)6.0F, (double)50.0F);
         TextRenderer.drawString(charSequence, drawContext, n, n2, Color.WHITE.getRGB());
      }
   }

   private static byte[] brdaposwnczucua() {
      return new byte[]{98, 92, 52, 27, 7, 88, 41, 125, 66, 65, 37, 99, 61, 68, 5, 26, 118, 48, 126, 26, 64, 42, 90, 37, 54, 61, 36, 48, 100, 73, 66, 17, 73, 98, 88, 39, 108, 21, 71, 5, 112, 15, 123, 80, 65, 78, 19, 40, 10, 96, 118, 55, 22, 6, 49, 97, 118, 86, 110, 127, 112, 126, 98, 10, 60, 94, 107, 36, 104, 70, 62, 71, 11, 77, 120, 62, 26, 68, 118, 87, 45, 21, 21};
   }
}
